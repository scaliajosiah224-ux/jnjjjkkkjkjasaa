# RingRing Android App - Build Guide for Google Play Store

## 📱 App Details
- **App Name**: RingRing
- **Package ID**: com.ringring.app
- **Min SDK**: Android 5.1+ (API 22)
- **Target SDK**: Android 14 (API 34)

## 🛠 Prerequisites
1. **Android Studio** (Latest version) — https://developer.android.com/studio
2. **Java JDK 17+** — https://adoptium.net/
3. **Git** — https://git-scm.com/

## 🚀 Build Steps

### Step 1: Open in Android Studio
1. Open Android Studio
2. Click "Open an Existing Project"
3. Select the `android/` folder from your RingRing project
4. Wait for Gradle sync to complete (may take 5-10 minutes first time)

### Step 2: Build Debug APK (for testing)
```bash
cd android/
./gradlew assembleDebug
```
APK will be at: `android/app/build/outputs/apk/debug/app-debug.apk`

### Step 3: Build Release APK (for Play Store)

#### Generate a Signing Keystore (one-time setup)
```bash
keytool -genkey -v -keystore ringring.keystore \
  -alias ringring \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```
When prompted:
- First/Last name: RingRing App
- Organization: Your Company Name
- City, State, Country: Your info
- **SAVE THE KEYSTORE FILE AND PASSWORD SECURELY!**

#### Add Signing Config to build.gradle
Edit `android/app/build.gradle` and add:
```gradle
signingConfigs {
    release {
        storeFile file('ringring.keystore')    // put keystore in android/app/
        storePassword 'YOUR_STORE_PASSWORD'
        keyAlias 'ringring'
        keyPassword 'YOUR_KEY_PASSWORD'
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}
```

#### Build Signed Release APK
```bash
cd android/
./gradlew assembleRelease
```
APK will be at: `android/app/build/outputs/apk/release/app-release.apk`

#### Build AAB (Recommended for Play Store)
```bash
cd android/
./gradlew bundleRelease
```
AAB at: `android/app/build/outputs/bundle/release/app-release.aab`

## 📤 Google Play Store Submission

### Requirements Checklist
- [ ] Signed APK or AAB file
- [ ] App icon (512x512 PNG)
- [ ] Feature graphic (1024x500 PNG)
- [ ] Screenshots (min 2 phone screenshots)
- [ ] Short description (max 80 chars): "Free phone number, SMS & calling app"
- [ ] Full description
- [ ] Privacy Policy URL

### App Listing Details
- **Category**: Communication
- **Content Rating**: Everyone
- **Age Rating**: 4+
- **Price**: Free

### Play Store URLs
- Developer Console: https://play.google.com/console
- Create new app > Upload APK/AAB > Fill details > Publish

## 🔑 App Permissions (Required)
The following permissions will be shown to users:
- INTERNET - For all app functionality
- RECORD_AUDIO - For voice/video calls
- CAMERA - For video calls
- READ_CONTACTS - For contact sync
- CALL_PHONE - For phone calls
- POST_NOTIFICATIONS - For call/message alerts

## 📋 App Store Listing Copy

### Short Description
"Free phone number for calls, texts & video chats"

### Full Description
```
🔔 RingRing - Your Free Second Phone Number

Get a FREE US phone number and start calling & texting instantly!

📱 FREE PHONE NUMBER
• Get a real US phone number in minutes
• Choose your own area code
• No SIM card needed

💬 SMS & MMS MESSAGING
• Send unlimited text messages
• Message anyone — they don't need the app
• Real-time delivery status

📞 VOICE CALLING
• Free app-to-app calls
• Call real phone numbers (PSTN)
• Crystal clear HD voice

🎥 VIDEO CALLING
• Face-to-face video calls
• High quality video

👥 CONTACTS
• Sync with your contacts
• Manage your phonebook

🔒 PRIVACY & SECURITY
• End-to-end encryption
• Protect your real number

Download RingRing today and get your free number!
```

## 🎨 Icon Generation
To generate all required Android icon sizes, use:
- Android Asset Studio: https://romannurik.github.io/AndroidAssetStudio/
- Or use the Capacitor Assets plugin

## ⚡ Troubleshooting

### Gradle sync fails
- Check Java version: `java -version` (needs 17+)
- Update Android Studio to latest
- File > Invalidate Caches > Restart

### AAPT2 errors
- Make sure build-tools are installed in Android Studio
- SDK Manager > SDK Tools > Android SDK Build-Tools

### App crashes on launch
- Check logcat in Android Studio
- Ensure the backend URL is accessible from the device

## 🔗 Backend Configuration
The app connects to:
```
Backend API: https://979402b8-bc7d-4e07-abab-743d020a20b8.preview.emergentagent.com
```

For production, update `REACT_APP_BACKEND_URL` in `.env` and rebuild.
