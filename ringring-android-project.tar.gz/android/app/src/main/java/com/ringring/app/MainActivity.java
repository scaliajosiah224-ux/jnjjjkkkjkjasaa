package com.ringring.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
