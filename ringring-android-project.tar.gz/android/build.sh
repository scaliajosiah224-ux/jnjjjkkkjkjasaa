#!/bin/bash
# RingRing Android Build Script
# Run this on your local machine (macOS/Windows/Linux x86_64)

set -e

echo "🔔 RingRing Android Build Script"
echo "================================"

# Check Java
if ! command -v java &> /dev/null; then
    echo "❌ Java not found! Install JDK 17 from https://adoptium.net/"
    exit 1
fi
echo "✅ Java: $(java -version 2>&1 | head -1)"

# Check Android SDK
if [ -z "$ANDROID_HOME" ]; then
    echo "⚠️  ANDROID_HOME not set. Looking for Android Studio..."
    if [ -d "$HOME/Library/Android/sdk" ]; then
        export ANDROID_HOME="$HOME/Library/Android/sdk"
    elif [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
    else
        echo "❌ Android SDK not found! Install Android Studio."
        exit 1
    fi
fi
echo "✅ Android SDK: $ANDROID_HOME"

# Make gradlew executable
chmod +x gradlew

# Build type selection
BUILD_TYPE=${1:-debug}

if [ "$BUILD_TYPE" = "release" ]; then
    echo "📦 Building RELEASE APK for Play Store..."
    ./gradlew bundleRelease
    echo ""
    echo "✅ Release AAB built!"
    echo "📂 Location: app/build/outputs/bundle/release/app-release.aab"
    echo ""
    echo "📤 Upload this .aab file to Google Play Console"
else
    echo "🔧 Building DEBUG APK for testing..."
    ./gradlew assembleDebug
    echo ""
    echo "✅ Debug APK built!"
    echo "📂 Location: app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "📱 Install on device:"
    echo "   adb install app/build/outputs/apk/debug/app-debug.apk"
fi
